pid_to_question_template_v2 = {
    'P21': [
        'How is ${entity}\'s sex or gender identity defined exactly?',
        'What defines the sex or gender identity of ${entity} clearly?',
        'How would you describe ${entity}\'s sex or gender identity?',
        'In what terms is ${entity}\'s gender identity or sex specified?',
        'Which description applies to ${entity}\'s sex or gender identity?'
    ],
    'P569': [
        'What is the exact year ${entity} was born?',
        'Can you specify which year ${entity} was born exactly?',
        'In which year was ${entity} officially born?',
        'Could you tell me ${entity}\'s year of birth?',
        'Which year did the birth of ${entity} take place?'
    ],
    'P106': [
        'What is the professional occupation of ${entity} exactly?',
        'Which job role does ${entity} currently hold or perform?',
        'Can you specify ${entity}\'s professional job or role?',
        'What occupation or position does ${entity} have now?',
        'Which professional role is assigned to ${entity}?'
    ],
    'P27': [
        'Which country does ${entity} officially have citizenship in?',
        'What nation grants citizenship status to ${entity}?',
        'Can you tell me where ${entity} holds citizenship?',
        'In which country is ${entity} a legal citizen?',
        'Which state recognizes ${entity} as its citizen?'
    ],
    'P19': [
        'Where exactly was ${entity} born or delivered?',
        'What is the precise birthplace of ${entity}?',
        'In which location was ${entity} born exactly?',
        'Can you specify ${entity}\'s place of birth?',
        'What place marks the birth of ${entity}?'
    ],
    'P17': [
        'Which country is ${entity} geographically located within?',
        'Where is ${entity} situated on the world map?',
        'In what country is ${entity} officially found?',
        'What nation contains ${entity} geographically?',
        'Which country does ${entity} belong to in location?'
    ],
    'P570': [
        'What year did ${entity} pass away or die?',
        'In which year did ${entity}\'s death occur?',
        'When exactly did ${entity} pass away?',
        'Can you specify ${entity}\'s year of death?',
        'What is the official year ${entity} died?'
    ],
    'P136': [
        'What genre is ${entity} mainly associated with?',
        'Which field does ${entity} typically work within?',
        'Can you specify ${entity}\'s involved genre or field?',
        'In what genre or area is ${entity} active?',
        'What specific field is ${entity} linked to?'
    ],
    'P571': [
        'Which year was ${entity} officially founded or established?',
        'What year marks the founding of ${entity}?',
        'Can you tell me which year ${entity} was established?',
        'In which year was ${entity} formally created?',
        'What is ${entity}\'s official founding year?'
    ],
    'P1412': [
        'What language does ${entity} commonly speak or use?',
        'Which languages are spoken by ${entity} regularly?',
        'Can you specify the languages used by ${entity}?',
        'In what language does ${entity} usually communicate?',
        'Which language is primarily used by ${entity}?'
    ],
    'P20': [
        'Where did ${entity} pass away or die exactly?',
        'What is the exact place ${entity} died in?',
        'Can you specify ${entity}\'s place of death?',
        'In which location did ${entity} pass away?',
        'Where was ${entity} when death occurred?'
    ],
    'P69': [
        'Which school or institution did ${entity} attend?',
        'Where did ${entity} receive formal education?',
        'What educational institution enrolled ${entity}?',
        'Can you specify where ${entity} studied?',
        'In which place was ${entity} educated?'
    ],
    'P577': [
        'Which year was ${entity} first published or released?',
        'What year marks ${entity}\'s official release?',
        'Can you specify the year when ${entity} was published?',
        'In which year did ${entity} come out?',
        'What is ${entity}\'s initial release year?'
    ],
    'P131': [
        'Where is ${entity} administratively located now?',
        'Which administrative area contains ${entity}?',
        'In what jurisdiction is ${entity} situated?',
        'Can you specify ${entity}\'s administrative region?',
        'Which governing entity covers ${entity}\'s location?'
    ],
    'P495': [
        'Which country is the origin of ${entity}?',
        'Where does ${entity} originally come from?',
        'What nation is considered ${entity}\'s origin?',
        'Can you specify ${entity}\'s country of origin?',
        'From which country does ${entity} originate?'
    ],
    'P26': [
        'Who is the legal spouse of ${entity}?',
        'Can you specify who ${entity} is married to?',
        'Who is recognized as ${entity}\'s partner?',
        'Who holds marital status with ${entity}?',
        'Who is officially wed to ${entity}?'
    ],
    'P264': [
        'Which music label is linked to ${entity}?',
        'Who represents ${entity} in the music industry?',
        'What label officially associates with ${entity}?',
        'Can you specify ${entity}\'s music label?',
        'Which record company works with ${entity}?'
    ],
    'P40': [
        'Who is recognized as ${entity}\'s child?',
        'Can you specify the child of ${entity}?',
        'Who is officially ${entity}\'s offspring?',
        'Which person is the child of ${entity}?',
        'Who is identified as ${entity}\'s descendant?'
    ],
    'P159': [
        'Where is ${entity}\'s headquarters located now?',
        'What place hosts ${entity}\'s main office?',
        'Can you specify ${entity}\'s head office location?',
        'In which city is ${entity} headquartered?',
        'Where are the headquarters of ${entity} situated?'
    ],
    'P175': [
        'Who performed ${entity} or is linked to it?',
        'Which artist is associated with ${entity}?',
        'Who is the performer of ${entity} exactly?',
        'Can you specify ${entity}\'s performer?',
        'Who is recognized as ${entity}\'s performer?'
    ],
    'P407': [
        'What language is used by ${entity} mainly?',
        'Which language does ${entity} typically use?',
        'In what language does ${entity} operate?',
        'Can you specify ${entity}\'s working language?',
        'Which language is spoken in ${entity}?'
    ],
    'P166': [
        'What award was given to ${entity} officially?',
        'Which recognition has ${entity} received?',
        'Can you specify ${entity}\'s honors or awards?',
        'Which prize or title was awarded to ${entity}?',
        'What distinction does ${entity} hold?'
    ],
    'P22': [
        'Who is recognized as ${entity}\'s father?',
        'Can you specify who fathered ${entity}?',
        'Who is officially ${entity}\'s paternal parent?',
        'Which person is ${entity}\'s biological father?',
        'Who is identified as ${entity}\'s dad?'
    ],
    'P641': [
        'Which sport is ${entity} involved in mainly?',
        'What sport does ${entity} play or practice?',
        'Can you specify ${entity}\'s associated sport?',
        'In which sport is ${entity} active?',
        'What athletic field involves ${entity}?'
    ]
}
import copy
import pickle
import random
import time
from typing import Dict, List

import requests
from requests.adapters import HTTPAdapter
from tqdm import tqdm
from urllib3.util.retry import Retry

from utils.load_save_file import load_jsonl_file, write_jsonl
from utils.static_settings import pid_to_question_template_v2 as pid_to_question_template

# 初始化全局 Session
session = requests.Session()

# 配置重试策略
retries = Retry(total=5, backoff_factor=0.5, status_forcelist=[429, 500, 502, 503, 504])
adapter = HTTPAdapter(max_retries=retries)
session.mount('http://', adapter)
session.mount('https://', adapter)

# 设置全局 Headers 和代理
session.headers.update({
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Accept": "application/json",
    "Accept-Language": "en-US,en;q=0.9",
    "Connection": "keep-alive"
})
session.proxies.update({
    "http": "http://127.0.0.1:7890",
    "https": "http://127.0.0.1:7890"
})


def _get_qid(entity_name_list: List[str]) -> List[str]:
    base_url = "https://www.wikidata.org/w/api.php"
    qid_list = []

    for entity_name in tqdm(entity_name_list):
        params = {
            "action": "wbsearchentities",
            "format": "json",
            "search": entity_name,
            "language": "en",
            "type": "item",
            "limit": 1,
            "props": "url",
            "formatversion": 2,
        }
        try:
            response = session.get(base_url, params=params, timeout=10)
            response.raise_for_status()
            data = response.json().get("search")[0]

            qid = data["id"]
            qid_list.append(qid)
        except requests.exceptions.RequestException as e1:
            print(f"[Network Error] Failed to fetch {entity_name}: {e1}")
        except ValueError as e2:
            print(f"[Parse Error] Invalid JSON response for {entity_name}: {e2}")
        except KeyError as e3:
            print(f"[Key Error] Invalid Response, Probably fail to match for {entity_name}: {e3}")

        # 防止频繁请求
        time.sleep(random.uniform(0.2, 0.5))

    return qid_list


def _get_wikidata_statements(QID_List: List[str]) -> Dict:
    base_url = "https://www.wikidata.org/w/api.php"
    result_dict = {}

    batch_size = 50
    total = len(QID_List)

    for i in tqdm(range(0, total, batch_size)):
        batch_qids = QID_List[i:i + batch_size]
        ids_param = "|".join(batch_qids)

        params = {
            "action": "wbgetentities",
            "format": "json",
            "ids": ids_param,
            "props": "claims",
            "languages": "en",
            "formatversion": 2
        }

        try:
            response = session.get(base_url, params=params, timeout=10)
            response.raise_for_status()
            data = response.json()

            entities = data.get("entities", {})
            for qid, info in entities.items():
                claims = info.get("claims", {})
                if claims:
                    result_dict[qid] = claims
                else:
                    result_dict[qid] = None
        except requests.exceptions.RequestException as e:
            print(f"[Network Error] Failed to fetch batch {batch_qids}: {e}")
        except ValueError:
            print(f"[Parse Error] Invalid JSON response for batch {batch_qids}")

        # 防止频繁请求
        time.sleep(random.uniform(0.2, 0.5))

    return result_dict


def _extract_statements(qid_statement_dict: Dict) -> List:
    def process_wikidata_time(v):
        # 去掉前缀+，处理Z
        if v.startswith('+'):
            v = v[1:]
        v = v.replace('Z', '')

        year = v[0:4]
        month = v[5:7]
        day = v[8:10]

        results = [year]

        try:
            # 判断月份是否合法
            month_int = int(month)
            if 1 <= month_int <= 12:
                results.append(f"{year}-{month}")
                # 判断日期是否合法
                day_int = int(day)
                if 1 <= day_int <= 31:
                    # 最终拼接年月日字符串
                    results.append(f"{year}-{month}-{day}")
        except:
            pass  # 遇到无法转换的情况，忽略

        return results

    relation_pairs = []
    for qid, claims in qid_statement_dict.items():
        for pid, contents in claims.items():
            if pid not in pid_to_question_template.keys():
                continue
            acceptable_answers = []
            for ctx in contents:
                data_type = ctx["mainsnak"]["datatype"]
                if ctx["mainsnak"]["snaktype"] == "somevalue" or ctx["mainsnak"]["snaktype"] == "novalue":
                    continue
                if data_type == "time":
                    value = ctx["mainsnak"]["datavalue"]["value"]["time"]
                    acceptable_answers += process_wikidata_time(value)
                else:
                    acceptable_answers += [ctx["mainsnak"]["datavalue"]["value"]["id"]]
            relation_pairs.append([qid, pid, acceptable_answers])
    return relation_pairs


def _get_entity_name_from_qid(QID_List):
    base_url = "https://www.wikidata.org/w/api.php"
    qid_to_title_dict = {}

    batch_size = 50
    total = len(QID_List)

    for i in tqdm(range(0, total, batch_size)):
        batch_qids = QID_List[i:i + batch_size]
        ids_param = "|".join(batch_qids)

        params = {
            "action": "wbgetentities",
            "format": "json",
            "ids": ids_param,
            "props": "labels",
            "languages": "en",
            "formatversion": 2
        }

        try:
            response = session.get(base_url, params=params, timeout=10)
            response.raise_for_status()
            data = response.json()

            entities = data.get("entities", {})
            for qid, info in entities.items():
                try:
                    labels = info.get("labels", {})
                    title = labels.get("en").get("value")
                except AttributeError:
                    print(qid)
                    title = None
                qid_to_title_dict[qid] = title

        except requests.exceptions.RequestException as e:
            print(f"[Network Error] Failed to fetch batch {batch_qids}: {e}")
        except ValueError:
            print(f"[Parse Error] Invalid JSON response for batch {batch_qids}")

        # 防止频繁请求，随机延迟
        time.sleep(random.uniform(0.2, 0.5))
    return qid_to_title_dict


def _format_dataset(statement_triplets, qid_to_title):
    data = []
    for triplet in statement_triplets:
        qid, pid, answers = triplet
        if qid_to_title[qid] is None:
            print(f"Entity Name Not Found: {qid}")
            continue
        answers = [qid_to_title[ans] if ans.startswith("Q") else ans for ans in answers]
        d = {
            "qid": qid,
            "question_list": [template.replace("${entity}", qid_to_title[qid]) for template in pid_to_question_template[pid]],
            "question_entity": qid_to_title[qid],
            "relation": pid,
            "answer_list": answers
        }
        data.append(d)
    return data


def make_dataset(
        exist_dataset_path,
        output_path,
):
    # Step 1. 从已有数据集中收集实体
    data = load_jsonl_file(exist_dataset_path)  # 读取已有数据集及其中的实体名称标注
    entity_name_list = [d["question_entity"] for d in data]
    entity_name_list = list(set(entity_name_list))  # 去除重复数据

    # 获取QID
    qid_list = _get_qid(entity_name_list)

    # 暂存结果，避免后续代码报错时需要重新请求获取
    with open("/home/pp/noise_in_rag/data/granola_qa/qid_list.pkl", "wb") as f:
        pickle.dump(qid_list, f)

    # Step 2. 收集每个实体在Wikidata中给出的声明和连接到的实体
    # 读取之前的暂存结果
    with open("/home/pp/noise_in_rag/data/granola_qa/qid_list.pkl", "wb") as f:
        qid_list = pickle.load(f)

    # 获取每个QID对应的Statement和连接的QID
    qid_statement_dict = _get_wikidata_statements(qid_list)

    # 暂存结果
    with open("/home/pp/noise_in_rag/data/granola_qa/qid_statement_dict.pkl", "wb") as f:
        pickle.dump(qid_statement_dict, f)
    # 读取之前的暂存结果
    with open("/home/pp/noise_in_rag/data/granola_qa/qid_statement_dict.pkl", "rb") as f:
        qid_statement_dict = pickle.load(f)

    # 获取statement triplets
    statement_triplets = _extract_statements(qid_statement_dict)

    qids = []
    for pair in statement_triplets:
        qids.append(pair[0])
        for answer in pair[2]:  # 可能每个Statement对应有多个QID答案
            if answer.startswith("Q"):
                qids.append(answer)
    qids = list(set(qids))  # 去重
    qid_to_title = _get_entity_name_from_qid(qids)

    # 暂存结果
    with open("/home/pp/noise_in_rag/data/granola_qa/qid_to_title.pkl", "wb") as f:
        pickle.dump(qid_to_title, f)

    # Step 3. 选择最常出现的20个声明，人工或AI给出5个问题模板,填写到Static_settings.py
    # from collections import Counter
    # statement_pids = [t[1] for t in statement_triplets]
    # counter = Counter(statement_pids)
    # print(counter.most_common(50))  # 可以适当多输出一些最常见的statement，再进行筛选
    #
    # # 人工筛选top_20 most common statement
    #
    # # 用AI工具生成问题模板

    # Step 4. 组合数据集
    # 读取之前的暂存结果
    with open("/home/pp/noise_in_rag/data/granola_qa/qid_to_title.pkl", "rb") as f:
        qid_to_title = pickle.load(f)
    data = _format_dataset(statement_triplets, qid_to_title)
    write_jsonl(data, output_path)


if __name__ == '__main__':
    make_dataset(
        exist_dataset_path="/home/pp/noise_in_rag/data/granola_qa/granola_qa_origin.jsonl",
        output_path="/home/pp/noise_in_rag/data/own_dataset/data_v2.jsonl",
    )
